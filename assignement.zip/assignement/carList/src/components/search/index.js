import React from "react";
import { useState } from "react/cjs/react.development";
import { ButtonTypes } from '../../models/common.models';
import Button from "../../shared-components/button";

const SearchBox = ({ onSearch }) => {

   const [searchText, setSearchText] = useState('');
   const [type, setType] = useState(ButtonTypes.Secondary)

   const handleOnChange = (e) => {
      let searchVal = '';
      let buttonType = ButtonTypes.Secondary;

      if (e.target.value && e.target.value.trim().length > 0) {
         searchVal = e.target.value.trim().toLowerCase();
         buttonType = ButtonTypes.Primary;
      }

      setSearchText(searchVal);
      setType(buttonType)
   }

   const handleOnClick = () => {
      onSearch(searchText);
   }

   return <div className="searchBox">
      <input type='input' placeholder="Search here" onChange={handleOnChange} />
      <Button buttonTxt='Search' type={type} handleOnClick={handleOnClick} />
   </div>
}

export default SearchBox;
