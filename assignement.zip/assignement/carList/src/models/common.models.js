export const ButtonTypes = {
   Primary: 'primaryBtn',
   Secondary: 'secondaryBtn'
}