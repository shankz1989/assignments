import React from "react";

const CarDetails = ({ filteredCarList }) => {
   return <div className="carDetailsContainer">
      {filteredCarList.length > 0 ? filteredCarList.map((item, index) => {
         return <div className="carDetails" key={index}>
            <div>Name: {item.Name}</div>
            <div>Price: {item.Price}</div>
            <div>Color: {item.Color}</div>
            <div>Waiting Time: {item.WaitingTime}</div>
         </div>
      }) : <p>No Car found.</p>}
   </div>
}

export default CarDetails;