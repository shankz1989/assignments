import React, { useEffect, useState } from "react";
import { getCarList } from '../../services/car-list.service';
import CarDetails from "../car-details";
import SearchBox from "../search";

const Home = () => {

   const [mainCarList, setMainCarList] = useState([]);
   const [filteredCarList, setFilteredCarList] = useState([]);

   useEffect(() => {
      const carList = getCarList();
      setMainCarList(carList);
      setFilteredCarList(carList);
   }, []);

   // Filter the cars based on the search
   const handleSearchClicked = (searchTxt) => {
      let filteredCarList = [];
      if (searchTxt) {
         filteredCarList = mainCarList.filter(i => i.Name.toLowerCase().indexOf(searchTxt) !== -1);
      } else {
         filteredCarList = [...mainCarList];
      }

      setFilteredCarList(filteredCarList)
   }

   return <div className="mainContainer">
      <h2 className="header">Welcome to Shanky`s Car Dealership</h2>
      <SearchBox onSearch={handleSearchClicked} />
      <CarDetails filteredCarList={filteredCarList} />
   </div>
}

export default Home;
