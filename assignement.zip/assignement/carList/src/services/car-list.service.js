export const getCarList = () => {

   const callAPI = () => {
      return [
         {
            CarImage: 'sample image',
            Name: 'Tata Altroz',
            Price: 'Rs. 6,00,000',
            Color: 'Black',
            WaitingTime: 60
         },
         {
            CarImage: 'sample image',
            Name: 'Tata Tiago',
            Price: 'Rs. 4,00,000',
            Color: 'Grey',
            WaitingTime: 45
         },
         {
            CarImage: 'sample image',
            Name: 'Tata Safari',
            Price: 'Rs. 14,00,000',
            Color: 'Black',
            WaitingTime: 60
         },
         {
            CarImage: 'sample image',
            Name: 'Tata Harrier',
            Price: 'Rs. 15,00,000',
            Color: 'Black',
            WaitingTime: 50
         }
      ]
   }

   const carList = callAPI();

   return carList;

}
