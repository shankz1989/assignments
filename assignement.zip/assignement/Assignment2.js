const inputData = [
   { "Gender": "Male", "HeightCm": 171, "WeightKg": 96 }, {
      "Gender": "Male", "HeightCm": 161, "WeightKg": 85
   }, {
      "Gender": "Male", "HeightCm": 180, "WeightKg": 77
   }, {
      "Gender": "Female",
      "HeightCm": 166, "WeightKg": 62
   }, { "Gender": "Female", "HeightCm": 150, "WeightKg": 70 }, {
      "Gender": "Female", "HeightCm": 167, "WeightKg": 82
   }
];

const getCountOfOverweigthPeople = (inputData) => {

   const getBMICategoryAndHealthRisk = (item, countOfOverweightPeople) => {
      let category = '';
      let healthRisk = '';
      if (item.bmi <= 18.4) {
         category = 'Underweight';
         healthRisk = 'Malnutrition risk';
      } else if (item.bmi = 18.5 && item.bmi <= 24.9) {
         category = 'Normal Weight';
         healthRisk = 'Low risk';
      } else {
         countOfOverweightPeople++;
         if (item.bmi >= 25 && item.bmi <= 29.9) {
            category = 'Overweight';
            healthRisk = 'Enhanced risk';
         } else if (item.bmi >= 30 && item.bmi <= 34.9) {
            category = 'Moderately Obese';
            healthRisk = 'Medium risk';
         } else if (item.bmi >= 35 && item.bmi <= 39.9) {
            category = 'Severely Obese';
            healthRisk = 'High risk';
         } else {
            category = 'Very Severely Obese';
            healthRisk = 'Very High risk';
         }
      }

      item.BMICategory = category;
      item.HealthRisk = healthRisk;

      return countOfOverweightPeople;
   }

   let countOfOverweightPeople = 0;
   inputData.map((item) => {
      item.BMI = item.WeightKg / (item.HeightCm / 100);
      countOfOverweightPeople = getBMICategoryAndHealthRisk(item, countOfOverweightPeople);
   })

   return countOfOverweightPeople;
}

const countOfOverweightPeople = getCountOfOverweigthPeople(inputData);

