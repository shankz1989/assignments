import React from 'react';

const Button = ({ buttonTxt, type, handleOnClick }) => {
   return <input type='button' value={buttonTxt} className={type} onClick={handleOnClick} />
}

export default Button;
